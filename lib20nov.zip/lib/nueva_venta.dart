import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'models/product.dart';
import 'constants/colors.dart';
import 'products_page.dart';

class ItemVenta {
  final Product producto;
  int cantidad;
  ItemVenta({required this.producto, this.cantidad = 1});
}

class NuevaVentaPage extends StatefulWidget {
  final String tipo;
  const NuevaVentaPage({super.key, required this.tipo});

  @override
  State<NuevaVentaPage> createState() => _NuevaVentaPageState();
}

class _NuevaVentaPageState extends State<NuevaVentaPage> {
  List<ItemVenta> items = [];
  List<Product> productosDisponibles = [];
  List<Product> productosFiltrados = [];
  String searchText = '';
  double dineroRecibido = 0.0;

  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance.collection('products')
        .where('deleted', isEqualTo: false)
        .get()
        .then((snapshot) {
      final productos = snapshot.docs.map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>, doc.id)).toList();
      setState(() {
        productosDisponibles = productos;
        productosFiltrados = productos;
      });
    });
  }

  void actualizarFiltro(String value) {
    final texto = value.trim().toLowerCase();
    setState(() {
      searchText = texto;
      productosFiltrados = productosDisponibles.where((p) =>
      p.invoiceNumber.toLowerCase().contains(texto) ||
          p.description.toLowerCase().contains(texto)
      ).toList();
    });
  }

  void agregarProducto(Product producto) {
    final index = items.indexWhere((i) => i.producto.id == producto.id);
    if (index >= 0) {
      if (items[index].cantidad < producto.stock) {
        setState(() => items[index].cantidad++);
      }
    } else {
      setState(() => items.add(ItemVenta(producto: producto)));
    }
  }

  double get total => items.fold(0.0, (suma, item) {
    final precio = widget.tipo == 'rappi' ? item.producto.rappiPrice : item.producto.publicPrice;
    return suma + (precio * item.cantidad);
  });

  Future<void> confirmarVenta() async {
    final sinStock = items.any((i) => i.cantidad > i.producto.stock);
    if (items.isEmpty || sinStock) return;
    final batch = FirebaseFirestore.instance.batch();
    for (var item in items) {
      final ref = FirebaseFirestore.instance.collection('products').doc(item.producto.id);
      batch.update(ref, {
        'stock': FieldValue.increment(-item.cantidad),
      });
    }
    await batch.commit();
    if (mounted) {
      Navigator.of(context).pop();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ProductsPage()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Venta ${widget.tipo}')),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Buscar por factura o descripción',
                border: OutlineInputBorder(),
              ),
              onChanged: actualizarFiltro,
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: productosFiltrados.length,
                itemBuilder: (_, i) {
                  final producto = productosFiltrados[i];
                  return ListTile(
                    title: Text('${producto.invoiceNumber} - ${producto.description}'),
                    subtitle: Text('Stock: ${producto.stock}'),
                    onTap: () => agregarProducto(producto),
                  );
                },
              ),
            ),
            const Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final item = items[i];
                  final sinStock = item.cantidad > item.producto.stock;
                  final precio = widget.tipo == 'rappi' ? item.producto.rappiPrice : item.producto.publicPrice;
                  return ListTile(
                    tileColor: sinStock ? AppColors.rojoClaro : null,
                    title: Text(item.producto.description),
                    subtitle: Text('Cantidad: ${item.cantidad} | Subtotal: \$${(precio * item.cantidad).toStringAsFixed(2)}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(icon: const Icon(Icons.remove), onPressed: () {
                          setState(() {
                            if (item.cantidad > 1) item.cantidad--;
                          });
                        }),
                        IconButton(icon: const Icon(Icons.add), onPressed: () {
                          setState(() {
                            if (item.cantidad < item.producto.stock) item.cantidad++;
                          });
                        }),
                        IconButton(icon: const Icon(Icons.delete), onPressed: () {
                          setState(() {
                            items.removeAt(i);
                          });
                        }),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Dinero recibido'),
              onChanged: (v) => setState(() => dineroRecibido = double.tryParse(v) ?? 0.0),
            ),
            const SizedBox(height: 8),
            Text('Total: \$${total.toStringAsFixed(2)}'),
            Text('Cambio: \$${(dineroRecibido - total).toStringAsFixed(2)}'),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancelar', style: TextStyle(color: Colors.red)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.verdeConfirmacion),
                  onPressed: confirmarVenta,
                  child: const Text('Confirmar Venta'),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}

//nop funciona la busqueda