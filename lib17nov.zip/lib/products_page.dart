import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'constants/colors.dart';
import 'models/product.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({Key? key}) : super(key: key);

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  String _searchText = '';

  // Dialogo para registrar nuevo producto
  Future<void> _showNewProductDialog() async {
    TextEditingController invoiceController = TextEditingController();
    TextEditingController qtyController = TextEditingController();
    TextEditingController brandController = TextEditingController();
    TextEditingController descController = TextEditingController();
    TextEditingController costController = TextEditingController();
    bool showError = false;
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            title: const Text('Registrar nuevo producto'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: invoiceController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      label: RichText(
                        text: TextSpan(
                          text: 'Número de Factura',
                          style: TextStyle(color: Colors.grey[700]),
                          children: const [TextSpan(text: ' *', style: TextStyle(color: Colors.red))],
                        ),
                      ),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: qtyController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      label: Text('¿Cuántas unidades?'),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: brandController,
                    decoration: const InputDecoration(
                      label: Text('Marca'),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: descController,
                    decoration: InputDecoration(
                      label: RichText(
                        text: TextSpan(
                          text: 'Descripción',
                          style: TextStyle(color: Colors.grey[700]),
                          children: const [TextSpan(text: ' *', style: TextStyle(color: Colors.red))],
                        ),
                      ),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: costController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      label: RichText(
                        text: TextSpan(
                          text: 'Costo con IVA',
                          style: TextStyle(color: Colors.grey[700]),
                          children: const [TextSpan(text: ' *', style: TextStyle(color: Colors.red))],
                        ),
                      ),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  if (showError)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Por favor, completa los campos obligatorios.',
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Descartar', style: TextStyle(color: Colors.red)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: () async {
                  String inv = invoiceController.text.trim();
                  String desc = descController.text.trim();
                  String costText = costController.text.trim();
                  if (inv.isEmpty || desc.isEmpty || costText.isEmpty) {
                    setState(() {
                      showError = true;
                    });
                    return;
                  }
                  double? cost = double.tryParse(costText);
                  if (cost == null) {
                    setState(() {
                      showError = true;
                    });
                    return;
                  }
                  int qty = 0;
                  if (qtyController.text.trim().isNotEmpty) {
                    qty = int.tryParse(qtyController.text.trim()) ?? 0;
                  }
                  String brand = brandController.text.trim();
                  double publicPrice = double.parse((cost * (1 + 0.46)).toStringAsFixed(2));
                  double rappiPrice = double.parse((publicPrice * (1 + 0.35)).toStringAsFixed(2));
                  await FirebaseFirestore.instance.collection('products').doc(inv).set({
                    'invoiceNumber': inv,
                    'description': desc,
                    'brand': brand,
                    'costWithIVA': cost,
                    'publicPrice': publicPrice,
                    'rappiPrice': rappiPrice,
                    'stock': qty,
                    'deleted': false,
                  });
                  Navigator.of(context).pop();
                },
                child: const Text('Añadir'),
              ),
            ],
          );
        });
      },
    );
  }

  // Dialogo para añadir stock a un producto existente
  Future<void> _showAddStockDialog() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance.collection('products').where('deleted', isEqualTo: false).get();
    List<Product> allProducts = snapshot.docs.map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>, doc.id)).toList();
    TextEditingController invoiceController = TextEditingController();
    TextEditingController qtyController = TextEditingController();
    Product? matchedProduct;
    bool showError = false;
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setState) {
          void updateMatch(String input) {
            if (input.length >= 2) {
              String query = input;
              Product? found;
              try {
                found = allProducts.firstWhere(
                      (p) => p.invoiceNumber.startsWith(query),
                );
              } catch (_) {
                try {
                  found = allProducts.firstWhere(
                        (p) => p.invoiceNumber.contains(query),
                  );
                } catch (_) {
                  found = null;
                }
              }
              setState(() {
                matchedProduct = found;
              });
            } else {
              setState(() {
                matchedProduct = null;
              });
            }
          }

          return AlertDialog(
            title: const Text('Añadir stock'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: invoiceController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Número de Factura',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    updateMatch(value.trim());
                  },
                ),
                const SizedBox(height: 8),
                if (invoiceController.text.trim().length >= 2)
                  Text(
                    matchedProduct != null
                        ? ((matchedProduct!.brand.isNotEmpty ? matchedProduct!.brand + ' - ' : '') + matchedProduct!.description)
                        : 'Producto no encontrado',
                    style: TextStyle(color: matchedProduct != null ? Colors.black : Colors.red),
                  ),
                const SizedBox(height: 8),
                TextField(
                  controller: qtyController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Cantidad a añadir',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (showError)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      'Por favor, ingresa los datos correctamente.',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Descartar', style: TextStyle(color: Colors.red)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: () async {
                  String inv = invoiceController.text.trim();
                  int addQty = int.tryParse(qtyController.text.trim()) ?? 0;
                  if (inv.isEmpty || matchedProduct == null || addQty <= 0) {
                    setState(() {
                      showError = true;
                    });
                    return;
                  }
                  await FirebaseFirestore.instance.collection('products').doc(matchedProduct!.id).update({
                    'stock': matchedProduct!.stock + addQty
                  });
                  Navigator.of(context).pop();
                },
                child: const Text('Hecho'),
              ),
            ],
          );
        });
      },
    );
  }

  // Dialogo para registrar una venta (reducir stock)
  Future<void> _showSaleDialog() async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance.collection('products').where('deleted', isEqualTo: false).get();
    List<Product> allProducts = snapshot.docs.map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>, doc.id)).toList();
    TextEditingController invoiceController = TextEditingController();
    TextEditingController qtyController = TextEditingController();
    Product? matchedProduct;
    bool showError = false;
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setState) {
          void updateMatch(String input) {
            if (input.length >= 2) {
              String query = input;
              Product? found;
              try {
                found = allProducts.firstWhere(
                      (p) => p.invoiceNumber.startsWith(query),
                );
              } catch (_) {
                try {
                  found = allProducts.firstWhere(
                        (p) => p.invoiceNumber.contains(query),
                  );
                } catch (_) {
                  found = null;
                }
              }

              setState(() {
                matchedProduct = found;
              });
            } else {
              setState(() {
                matchedProduct = null;
              });
            }
          }

          return AlertDialog(
            title: const Text('Registrar venta'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: invoiceController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Número de Factura',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    updateMatch(value.trim());
                  },
                ),
                const SizedBox(height: 8),
                if (invoiceController.text.trim().length >= 2)
                  Text(
                    matchedProduct != null
                        ? ((matchedProduct!.brand.isNotEmpty ? matchedProduct!.brand + ' - ' : '') + matchedProduct!.description)
                        : 'Producto no encontrado',
                    style: TextStyle(color: matchedProduct != null ? Colors.black : Colors.red),
                  ),
                const SizedBox(height: 8),
                TextField(
                  controller: qtyController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Cantidad a vender',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (showError)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      'Datos inválidos o sin stock suficiente.',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Descartar', style: TextStyle(color: Colors.red)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: () async {
                  String inv = invoiceController.text.trim();
                  int sellQty = int.tryParse(qtyController.text.trim()) ?? 0;
                  if (inv.isEmpty || matchedProduct == null || sellQty <= 0 || matchedProduct!.stock < sellQty) {
                    setState(() {
                      showError = true;
                    });
                    return;
                  }
                  await FirebaseFirestore.instance.collection('products').doc(matchedProduct!.id).update({
                    'stock': matchedProduct!.stock - sellQty
                  });
                  Navigator.of(context).pop();
                },
                child: const Text('Hecho'),
              ),
            ],
          );
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          // Barra de búsqueda y botones de acción
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Buscar por factura o descripción',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchText = value.trim().toLowerCase();
                    });
                  },
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: _showNewProductDialog,
                child: const Text('Nuevo producto'),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _showAddStockDialog,
                child: const Text('Añadir stock'),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _showSaleDialog,
                child: const Text('Venta'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Lista de productos
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('products')
                  .where('deleted', isEqualTo: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                List<Product> products = snapshot.data!.docs
                    .map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>, doc.id))
                    .toList();
                // Filtrar por búsqueda
                if (_searchText.isNotEmpty) {
                  products = products.where((p) {
                    return p.invoiceNumber.toLowerCase().contains(_searchText) ||
                        p.description.toLowerCase().contains(_searchText);
                  }).toList();
                }
                // Ordenar: sin stock primero, stock bajo después, resto al final
                products.sort((a, b) {
                  int importanceA = (a.stock == 0) ? 2 : ((a.stock > 0 && a.stock < 2) ? 1 : 0);
                  int importanceB = (b.stock == 0) ? 2 : ((b.stock > 0 && b.stock < 2) ? 1 : 0);
                  if (importanceA != importanceB) {
                    return importanceB.compareTo(importanceA);
                  }
                  // Si misma importancia, ordenar por número de factura
                  int invA = int.tryParse(a.invoiceNumber) ?? -1;
                  int invB = int.tryParse(b.invoiceNumber) ?? -1;
                  if (invA != -1 && invB != -1) {
                    return invA.compareTo(invB);
                  }
                  return a.invoiceNumber.compareTo(b.invoiceNumber);
                });
                if (products.isEmpty) {
                  return const Center(child: Text('No hay productos.'));
                }
                return ListView.builder(
                  itemCount: products.length,
                  itemBuilder: (context, index) {
                    Product p = products[index];
                    // Color de fondo según stock
                    Color? tileColor;
                    if (p.stock == 0) {
                      tileColor = AppColors.redHighlight;
                    } else if (p.stock > 0 && p.stock < 2) {
                      tileColor = AppColors.yellowHighlight;
                    }
                    return Card(
                      color: tileColor,
                      child: ListTile(
                        title: Text('${p.invoiceNumber} - ${p.description}'),
                        subtitle: Text(
                          'Marca: ${p.brand.isNotEmpty ? p.brand : '-'}' '\nStock: ${p.stock}, Público: \$${p.publicPrice.toStringAsFixed(2)}, Rappi: \$${p.rappiPrice.toStringAsFixed(2)}',
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.grey),
                          onPressed: () async {
                            // Eliminación lógica
                            await FirebaseFirestore.instance.collection('products').doc(p.id).update({'deleted': true});
                          },
                        ),
                        isThreeLine: true,
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
