import 'package:flutter/material.dart';

class AppColors {
  static const Color blueSky = Color(0xFF87CEEB);
  static const Color darkGrey = Color(0xFF303030);
  static const Color green = Color(0xFF4CAF50);
  static const Color red = Color(0xFFF44336);
  static const Color yellow = Color(0xFFFFEB3B);
  static const Color redHighlight = Color(0xFFFFCDD2);
  static const Color yellowHighlight = Color(0xFFFFF9C4);
  static const Color negro = Color(0xFF000000);
}