import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'models/product.dart';

class DeletedPage extends StatelessWidget {
  const DeletedPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('products').where('deleted', isEqualTo: true).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        List<Product> deletedProducts = snapshot.data!.docs
            .map((doc) => Product.fromMap(doc.data() as Map<String, dynamic>, doc.id))
            .toList();
        // Ordenar por número de factura
        deletedProducts.sort((a, b) {
          int invA = int.tryParse(a.invoiceNumber) ?? -1;
          int invB = int.tryParse(b.invoiceNumber) ?? -1;
          if (invA != -1 && invB != -1) {
            return invA.compareTo(invB);
          }
          return a.invoiceNumber.compareTo(b.invoiceNumber);
        });
        if (deletedProducts.isEmpty) {
          return const Center(child: Text('No hay productos eliminados.'));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(8.0),
          itemCount: deletedProducts.length,
          itemBuilder: (context, index) {
            Product p = deletedProducts[index];
            return Card(
              child: ListTile(
                title: Text('${p.invoiceNumber} - ${p.description}'),
                subtitle: Text('Marca: ${p.brand.isNotEmpty ? p.brand : '-'}' '\nStock: ${p.stock}, Público: \$${p.publicPrice.toStringAsFixed(2)}, Rappi: \$${p.rappiPrice.toStringAsFixed(2)}'),
                isThreeLine: true,
              ),
            );
          },
        );
      },
    );
  }
}
