/*import 'package:flutter/material.dart';
import 'nueva_venta.dart';
import 'constants/colors.dart';

class TipoVentaPage extends StatelessWidget {
  const TipoVentaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tipo de Venta')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.verdeConfirmacion,
                  padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NuevaVentaPage(tipo: 'normal'),
                    ),
                  );
                },
                child: const Text('Venta Normal'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.azulPrincipal,
                  padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 32.0),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NuevaVentaPage(tipo: 'rappi'),
                    ),
                  );
                },
                child: const Text('Venta por Rappi'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}*/