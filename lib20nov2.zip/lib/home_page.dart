import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'constants/colors.dart';
import 'models/product.dart';
import 'products_page.dart';
import 'deleted_page.dart';
//import 'tipo_venta.dart';
import 'nueva_venta.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _currentSection = 'products';
  bool _importing = false;

  Future<void> _importExcelData() async {
    setState(() {
      _importing = true;
    });

    try {
      // Asegurarnos de que haya un usuario logueado
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Debes iniciar sesión para importar productos.')),
        );
        return;
      }

      // Colección de productos del usuario actual
      final userProductsCollection = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('products');

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final bytes = result.files.single.bytes;
        if (bytes != null) {
          var excel = Excel.decodeBytes(bytes);

          // Procesar solo la hoja "Precios MENUDEO"
          Sheet? sheet = excel.tables['Precios MENUDEO'];
          if (sheet != null) {
            WriteBatch batch = FirebaseFirestore.instance.batch();
            int count = 0;

            for (int r = 1; r < sheet.maxRows; r++) {
              List<Data?> row = sheet.row(r);

              // Extraer valores de celda de forma segura
              dynamic getCellValue(Data? cell) {
                if (cell == null) return null;
                var cellValue = cell.value;
                if (cellValue == null) return null;
                if (cellValue is FormulaCellValue) return null; // omitimos fórmulas
                if (cellValue is BoolCellValue) return cellValue.value;
                if (cellValue is IntCellValue) return cellValue.value;
                if (cellValue is DoubleCellValue) return cellValue.value;
                if (cellValue is TextCellValue) return cellValue.value;
                return cellValue;
              }

              var invVal  = getCellValue(row.length > 1 ? row[1] : null);
              var descVal = getCellValue(row.length > 3 ? row[3] : null);
              var costVal = getCellValue(row.length > 4 ? row[4] : null);

              // Validar campos obligatorios
              if (invVal == null || descVal == null || costVal == null) {
                continue;
              }

              String invoiceNumber = invVal.toString().trim();
              String description   = descVal.toString().trim();

              String brand = '';
              var brandVal = getCellValue(row.length > 2 ? row[2] : null);
              if (brandVal != null) {
                brand = brandVal.toString().trim();
              }

              // Stock
              int stock = 0;
              var stockVal = getCellValue(row.length > 0 ? row[0] : null);
              if (stockVal != null) {
                stock = (stockVal as num).toInt();
              }

              // Calcular precios
              double costWithIVA = (costVal as num).toDouble();
              double publicPrice =
              double.parse((costWithIVA * (1 + 0.46)).toStringAsFixed(2));
              double rappiPrice =
              double.parse((publicPrice * (1 + 0.35)).toStringAsFixed(2));

              // Datos del producto
              Map<String, dynamic> productData = {
                'invoiceNumber': invoiceNumber,
                'description': description,
                'brand': brand,
                'costWithIVA': costWithIVA,
                'publicPrice': publicPrice,
                'rappiPrice': rappiPrice,
                'stock': stock,
                'deleted': false,
              };

              // 👉 AHORA se guarda en /users/{uid}/products/{invoiceNumber}
              DocumentReference docRef =
              userProductsCollection.doc(invoiceNumber);

              batch.set(docRef, productData, SetOptions(merge: false));
              count++;

              // Commit por lotes de 500
              if (count % 500 == 0) {
                await batch.commit();
                batch = FirebaseFirestore.instance.batch();
              }
            }

            // Commit final
            await batch.commit();
          }
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al importar datos: $e')),
      );
    } finally {
      setState(() {
        _importing = false;
      });
    }
  }


  void _logout() async { await FirebaseAuth.instance.signOut(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Barra superior
          Container(
            color: AppColors.blueSky,
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            height: 50,
            width: double.infinity,
            alignment: Alignment.centerLeft,
            child: Text(
              'KTOOLS',
              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          // Contenido con menú lateral y área principal
          Expanded(
            child: Row(
              children: [
                // Menú lateral
                Container(
                  width: 200,
                  color: AppColors.darkGrey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        children: [
                          ListTile(
                            title: const Text('Productos', style: TextStyle(color: Colors.white)),
                            selected: _currentSection == 'products',
                            selectedTileColor: Colors.grey,
                            onTap: () {
                              setState(() {
                                _currentSection = 'products';
                              });
                            },
                          ),
                          ListTile(
                            title: const Text('Nueva Venta', style: TextStyle(color: Colors.white)),
                            onTap: () async {
                              final tipoSeleccionado = await showDialog<String>(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: const Text('Selecciona el tipo de venta'),
                                    content: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        ElevatedButton(
                                          onPressed: () => Navigator.pop(context, 'normal'),
                                          child: const Text('Venta normal'),
                                        ),
                                        const SizedBox(height: 8),
                                        ElevatedButton(
                                          onPressed: () => Navigator.pop(context, 'rappi'),
                                          child: const Text('Venta por Rappi'),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );

                              if (tipoSeleccionado != null) {
                                Navigator.of(context).push(
                                  MaterialPageRoute(builder: (_) => NuevaVentaPage(tipo: tipoSeleccionado)),
                                );
                              }
                            },
                          ),


                          ListTile(
                            title: const Text('Eliminados', style: TextStyle(color: Colors.white)),
                            selected: _currentSection == 'deleted',
                            selectedTileColor: Colors.grey,
                            onTap: () {
                              setState(() {
                                _currentSection = 'deleted';
                              });
                            },
                          ),
                          ListTile(
                            title: const Text('Importar Excel', style: TextStyle(color: Colors.white)),
                            onTap: () {
                              _importExcelData();
                            },
                          ),
                        ],
                      ),
                      ListTile(
                        title: const Text('Cerrar sesión', style: TextStyle(color: Colors.white)),
                        onTap: () {
                          _logout();
                        },
                      ),
                    ],
                  ),
                ),
                // Área de contenido principal
                Expanded(
                  child: _importing
                      ? const Center(child: CircularProgressIndicator())
                      : (_currentSection == 'products'
                      ? const ProductsPage()
                      : const DeletedPage()),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}