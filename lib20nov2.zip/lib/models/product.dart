class Product {
  String id;
  String invoiceNumber;
  String description;
  String brand;
  double costWithIVA;
  double publicPrice;
  double rappiPrice;
  int stock;
  bool deleted;

  Product({
    required this.id,
    required this.invoiceNumber,
    required this.description,
    required this.brand,
    required this.costWithIVA,
    required this.publicPrice,
    required this.rappiPrice,
    required this.stock,
    required this.deleted,
  });

  // Crea un Product a partir de un documento de Firestore
  factory Product.fromMap(Map<String, dynamic> data, String documentId) {
    return Product(
      id: documentId,
      invoiceNumber: data['invoiceNumber'] ?? '',
      description: data['description'] ?? '',
      brand: data['brand'] ?? '',
      costWithIVA: (data['costWithIVA'] as num?)?.toDouble() ?? 0.0,
      publicPrice: (data['publicPrice'] as num?)?.toDouble() ?? 0.0,
      rappiPrice: (data['rappiPrice'] as num?)?.toDouble() ?? 0.0,
      stock: (data['stock'] as num?)?.toInt() ?? 0,
      deleted: data['deleted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'invoiceNumber': invoiceNumber,
      'description': description,
      'brand': brand,
      'costWithIVA': costWithIVA,
      'publicPrice': publicPrice,
      'rappiPrice': rappiPrice,
      'stock': stock,
      'deleted': deleted,
    };
  }
}